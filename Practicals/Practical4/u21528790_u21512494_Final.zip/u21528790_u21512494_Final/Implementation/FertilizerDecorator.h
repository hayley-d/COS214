#ifndef FERTILIZERDECORATOR_H
#define FERTILIZERDECORATOR_H

#include "FarmDecorator.h"

/**
 * @class FertilizerDecorator
 * @brief A decorator class that applies fertilizer to enhance crop yield in a farm unit.
 * 
 * The FertilizerDecorator class extends the functionality of FarmComposite objects by allowing 
 * the application of fertilizer, which increases crop production and facilitates harvesting.
 */
class FertilizerDecorator : public FarmDecorator {
public:
    /**
     * @brief Constructs a FertilizerDecorator with a FarmComposite object to wrap.
     * 
     * @param wrapee The FarmComposite object that is being decorated with fertilizer functionality.
     */
    FertilizerDecorator(FarmComposite &wrapee)
        : FarmDecorator(wrapee) {
    }

    /**
     * @brief Applies the fertilizer enhancement to the wrapped farm unit.
     * 
     * This method overrides the applyEnhancement method in the base class and performs the actions
     * needed to increase crop production.
     */
    void applyEnhancement() override;

    /**
     * @brief Destructor for FertilizerDecorator.
     */
    ~FertilizerDecorator() override = default;

protected:
    /**
     * @brief Increases crop production by applying fertilizer.
     * 
     * This method simulates the effect of fertilizer, increasing the crop yield of the farm unit.
     */
    void increaseProduction();

    /**
     * @brief Harvests crops after the fertilizer has been applied.
     * 
     * This method simulates the harvesting process based on the enhanced production from the fertilizer.
     */
    void harvest();
};

#endif //FERTILIZERDECORATOR_H
