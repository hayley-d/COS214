#ifndef EVENT_H
#define EVENT_H

/**
 * @enum Event
 * @brief Represents the types of events that can occur in the farm system.
 * 
 * This enum defines the different events that may trigger specific actions, such as notifying trucks or changing soil states.
 */
enum Event {
    SOIL_CHANGE,   /**< Indicates a change in the soil state (e.g., dry to fruitful). */
    STORAGE_FULL   /**< Indicates that the storage capacity of a farm unit is full. */
};

#endif //EVENT_H
