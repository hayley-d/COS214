#ifndef LOGISTICSTRUCK_H
#define LOGISTICSTRUCK_H

#include "Truck.h"

/**
 * @class LogisticsTruck
 * @brief A truck used for managing logistics on the farm, such as delivering fertilizer or collecting harvested crops.
 * 
 * The LogisticsTruck class extends the Truck base class and implements the functionality for responding to specific events on the farm.
 */
class LogisticsTruck : public Truck {
public:
    /**
     * @brief Constructs a LogisticsTruck associated with a specific farm unit.
     * 
     * @param farmUnit The FarmUnit that this logistics truck is responsible for.
     */
    LogisticsTruck(FarmUnit& farmUnit) {
        this->subject = &farmUnit;
    }

    /**
     * @brief Starts the truck's engine in response to an event.
     * 
     * This method overrides the startEngine function in the Truck base class, and is triggered by specific events like soil changes or full storage.
     * 
     * @param e The event that triggers the truck's operation (e.g., SOIL_CHANGE or STORAGE_FULL).
     */
    void startEngine(Event e) override;
};

#endif //LOGISTICSTRUCK_H
