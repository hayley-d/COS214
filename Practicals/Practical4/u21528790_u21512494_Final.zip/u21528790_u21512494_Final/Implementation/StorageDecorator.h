#ifndef STORAGEDECORATOR_H
#define STORAGEDECORATOR_H

#include "FarmDecorator.h"

/**
 * @class StorageDecorator
 * @brief A decorator class that adds extra storage capacity to farm units.
 * 
 * The StorageDecorator class enhances the functionality of a FarmComposite object by adding an extra barn,
 * which increases the farm's storage capacity.
 */
class StorageDecorator : public FarmDecorator {
public:
    /**
     * @brief Constructs a StorageDecorator with a FarmComposite object to wrap.
     * 
     * @param wrapee The FarmComposite object that is being decorated with extra storage capacity.
     */
    explicit StorageDecorator(FarmComposite &wrapee)
        : FarmDecorator(wrapee) {
    }

    /**
     * @brief Applies the storage enhancement to the wrapped farm unit.
     * 
     * This method overrides the applyEnhancement method in the base class and adds extra storage capacity
     * to the farm unit.
     */
    void applyEnhancement() override;

    /**
     * @brief Destructor for StorageDecorator.
     */
    ~StorageDecorator() override = default;

protected:
    /**
     * @brief Adds an extra barn to the farm unit to increase storage capacity.
     * 
     * This method simulates adding an additional storage barn to the farm unit.
     */
    void addExtraBarn();

    /**
     * @brief Returns the remaining storage capacity after adding the extra barn.
     * 
     * @return The leftover storage capacity in the farm unit.
     */
    int getLeftoverCapacity();
};

#endif //STORAGEDECORATOR_H
