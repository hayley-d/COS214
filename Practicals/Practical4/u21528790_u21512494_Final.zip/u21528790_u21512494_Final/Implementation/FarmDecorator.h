#ifndef FARMDECORATOR_H
#define FARMDECORATOR_H

#include "FarmUnit.h"

/**
 * @class FarmDecorator
 * @brief A decorator class for enhancing the functionality of FarmComposite objects.
 * 
 * The FarmDecorator class allows dynamic extension of FarmComposite functionality without modifying the underlying class.
 * It wraps around a FarmComposite object and can apply additional behaviors.
 */
class FarmDecorator : public FarmComposite {
    typedef std::shared_ptr<FarmUnit> FarmUnitPtr;  ///< Type alias for shared pointer to FarmUnit.
    typedef std::vector<std::shared_ptr<FarmUnit>> FarmUnitPtrVector;  ///< Type alias for a vector of shared pointers to FarmUnit.

public:
    /**
     * @brief Constructs a FarmDecorator with a FarmComposite object to wrap.
     * 
     * @param wrapee The FarmComposite object that is being decorated.
     */
    FarmDecorator(FarmComposite& wrapee) : 
        FarmComposite(wrapee.getTotalcapacity(), wrapee.getSurfaceArea(), wrapee.getCropType().crop), wrapee(&wrapee) {}

    /**
     * @brief Prints the details of the wrapped farm unit.
     * 
     * This method overrides the base class to call the printFarm method of the wrapped object.
     */
    void printFarm() override {
        this->wrapee->printFarm();
    }

    /**
     * @brief Applies an enhancement to the farm unit.
     * 
     * This is a pure virtual method that derived classes must implement to apply specific enhancements to the farm unit.
     */
    virtual void applyEnhancement() = 0;

    /**
     * @brief Destructor for the FarmDecorator class.
     * 
     * The destructor ensures that the wrapped farm unit is properly deleted.
     */
    ~FarmDecorator() override {
        delete wrapee;
    }

    /**
     * @brief Adds a FarmUnit to the wrapped FarmComposite object.
     * 
     * @param unit The FarmUnit to add.
     */
    void addFarmUnit(FarmUnitPtr unit) {
        wrapee->addFarmUnit(unit);
    }

    /**
     * @brief Removes a FarmUnit from the wrapped FarmComposite object.
     * 
     * @param unit The FarmUnit to remove.
     */
    void removeFarmUnit(FarmUnitPtr unit) {
        wrapee->removeFarmUnit(unit);
    }

protected:
    FarmComposite* wrapee;  ///< Pointer to the wrapped FarmComposite object.
};

#endif //FARMDECORATOR_H
