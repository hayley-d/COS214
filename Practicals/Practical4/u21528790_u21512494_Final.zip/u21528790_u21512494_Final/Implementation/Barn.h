#ifndef BARN_H
#define BARN_H
#include "FarmUnit.h"

/**
 * @class Barn
 * @brief Represents a Barn unit within the farm system.
 *
 * The Barn class inherits from the FarmUnit class and manages storage for a particular crop type. 
 * It allows access to various farm-related functionalities such as printing farm details.
 */
class Barn : public FarmUnit {
public:
    /**
     * @brief Constructs a Barn object with the specified capacity, surface area, and crop type.
     * 
     * @param totalCapacity The total storage capacity of the barn.
     * @param surfaceArea The surface area of the barn.
     * @param cropType The type of crop stored in the barn.
     */
    Barn(int totalCapacity, int surfaceArea, CropType cropType) : FarmUnit(
        totalCapacity, surfaceArea, cropType) {}

    /**
     * @brief Prints details about the barn and its associated farm units.
     *
     * This function overrides the printFarm method from the FarmUnit base class to display information
     * specific to the barn.
     */
    void printFarm() override;
};

#endif //BARN_H
