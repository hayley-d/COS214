var searchData=
[
  ['addextrabarn_103',['addExtraBarn',['../classStorageDecorator.html#a888442e93d2a4772046a09f008b65f4d',1,'StorageDecorator']]],
  ['addfarmunit_104',['addFarmUnit',['../classCropField.html#a5577a868865fb406cc2e0854438270ce',1,'CropField::addFarmUnit()'],['../classFarm.html#af5ae0e497fa886fd76b529f90490a345',1,'Farm::addFarmUnit()'],['../classFarmDecorator.html#ac3b81f52747bbda8998ebc20d3e3e90e',1,'FarmDecorator::addFarmUnit(FarmUnitPtr unit)']]],
  ['applyenhancement_105',['applyEnhancement',['../classFarmDecorator.html#aa8c458a3e50f627a50b1bb1e0965152d',1,'FarmDecorator::applyEnhancement()'],['../classFertilizerDecorator.html#abf3b6c5f751b818ee8f3a3c98b9bd8dc',1,'FertilizerDecorator::applyEnhancement()'],['../classStorageDecorator.html#a923a56c356181f0c7cfdb2250b1c72eb',1,'StorageDecorator::applyEnhancement()']]]
];
