var searchData=
[
  ['logisticstruck_143',['LogisticsTruck',['../classLogisticsTruck.html#ac3d6c1c3b60384c40205e846636ce1fe',1,'LogisticsTruck']]]
];
