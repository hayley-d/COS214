var searchData=
[
  ['logisticstruck_97',['LogisticsTruck',['../classLogisticsTruck.html',1,'']]]
];
